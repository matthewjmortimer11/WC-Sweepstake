/* ===========================================================================
   ADMIN — Wheesht's clipboard. Run the sweepstake through the tournament:
   set the phase, mark teams out (owners flip to eliminated automatically),
   enter match results (fixtures go live / done), and set prediction answers
   (everyone's score + the league re-grade instantly). All changes persist via
   Store and, in live mode, push to the backend so every device picks them up.
   =========================================================================== */
const WCa = window.WC;
const Wa = window.Wheesht;
const Sa = window.Store;
const { Card: Ca, Btn: Ba, Flag: Fa, Chip: Cha, SectionHead: SHa } = window;
const { useState: aState2 } = React;

function PhaseSeg() {
  const cur = Sa.phase();
  const opts = [['pre', 'Pre-kickoff'], ['live', 'In play'], ['done', 'Finished']];
  return (
    <div style={{ display: 'flex', gap: 8 }}>
      {opts.map(([k, lab]) => (
        <button key={k} onClick={() => Sa.setPhase(k)} className="wc-btn wc-btn--sm"
          style={{ flex: 1, background: cur === k ? 'var(--yellow)' : '#fff', boxShadow: cur === k ? '0 4px 0 var(--ink)' : '0 4px 0 var(--shadow)' }}>{lab}</button>
      ))}
    </div>
  );
}

function TeamToggle(props) {
  const t = props.t; const owners = props.owners;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '8px 4px', borderBottom: '1.5px solid var(--line)', opacity: t.alive ? 1 : .6 }}>
      <Fa team={t} size={22} />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontWeight: 800, fontSize: 13.5, textDecoration: t.alive ? 'none' : 'line-through' }}>{t.name}</div>
        {owners > 0 && <div style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--red)' }}>{owners} in the draw</div>}
      </div>
      <button onClick={() => Sa.setTeamOut(t.code, t.alive)} className="wc-btn wc-btn--sm"
        style={{ padding: '6px 12px', background: t.alive ? '#fff' : 'var(--ink)', color: t.alive ? 'var(--ink)' : '#fff', boxShadow: t.alive ? '0 3px 0 var(--shadow)' : '0 3px 0 #000' }}>
        {t.alive ? 'Knock out' : 'Bring back'}
      </button>
    </div>
  );
}

function ScoreStepper(props) {
  const [a, setA] = aState2(props.a); const [b, setB] = aState2(props.b);
  const ta = WCa.TEAMS[props.f.a], tb = WCa.TEAMS[props.f.b];
  function step(box, setter, val, d) { var n = Math.max(0, val + d); setter(n); }
  const num = { width: 34, textAlign: 'center', fontFamily: 'var(--disp)', fontWeight: 800, fontSize: 22 };
  const sbtn = { width: 28, height: 28, borderRadius: 8, border: '2px solid var(--ink)', background: '#fff', fontWeight: 900, fontSize: 16, cursor: 'pointer', lineHeight: 1 };
  return (
    <div style={{ marginTop: 10, background: 'var(--bg)', borderRadius: 12, padding: '12px' }}>
      {[[ta, a, setA], [tb, b, setB]].map(([t, v, set], i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: i === 0 ? 8 : 0 }}>
          <span style={{ fontSize: 20 }}>{t.flag}</span>
          <span style={{ flex: 1, fontWeight: 800, fontSize: 14 }}>{t.name}</span>
          <button style={sbtn} onClick={() => step(i, set, v, -1)}>–</button>
          <span style={num}>{v}</span>
          <button style={sbtn} onClick={() => step(i, set, v, 1)}>+</button>
        </div>
      ))}
      <div style={{ display: 'flex', gap: 8, marginTop: 11 }}>
        <Ba variant="ink" sm block onClick={() => props.onSave(a, b)}>Save full-time</Ba>
        <button onClick={props.onCancel} className="wc-btn wc-btn--sm" style={{ boxShadow: '0 4px 0 var(--shadow)', padding: '0 14px' }}>Cancel</button>
      </div>
    </div>
  );
}

function FixtureAdminRow(props) {
  const f = props.f; const [open, setOpen] = aState2(false);
  const ta = WCa.TEAMS[f.a], tb = WCa.TEAMS[f.b];
  const st = f.status || 'upcoming';
  return (
    <Ca flat style={{ padding: '11px 13px', marginBottom: 8 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <div style={{ display: 'flex', gap: 5, alignItems: 'center', flex: 1, minWidth: 0 }}>
          <span style={{ fontSize: 18 }}>{ta.flag}</span>
          <span style={{ fontWeight: 800, fontSize: 13, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{ta.code}</span>
          <span style={{ color: 'var(--ink2)', fontWeight: 800, fontSize: 12, padding: '0 2px' }}>
            {st === 'done' && f.score ? f.score[0] + '–' + f.score[1] : 'v'}
          </span>
          <span style={{ fontWeight: 800, fontSize: 13, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{tb.code}</span>
          <span style={{ fontSize: 18 }}>{tb.flag}</span>
        </div>
        {st === 'done'
          ? <Cha tone="ink">FT</Cha>
          : st === 'live'
            ? <span style={{ fontSize: 10.5, fontWeight: 800, color: 'var(--red)' }}>● LIVE</span>
            : <span style={{ fontSize: 11, fontWeight: 700, color: 'var(--ink2)' }}>{f.time}</span>}
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 8 }}>
        <span style={{ fontSize: 10.5, fontWeight: 700, color: 'var(--ink2)', flex: 1 }}>Gp {f.group} · {f.dateLabel}</span>
        {st !== 'done' && <button onClick={() => Sa.setFixtureLive(f.id, st !== 'live')} className="wc-btn wc-btn--sm" style={{ padding: '5px 10px', boxShadow: '0 3px 0 var(--shadow)' }}>{st === 'live' ? 'Stop live' : 'Go live'}</button>}
        <button onClick={() => setOpen(!open)} className="wc-btn wc-btn--sm" style={{ padding: '5px 10px', boxShadow: '0 3px 0 var(--shadow)' }}>{st === 'done' ? 'Edit score' : 'Enter score'}</button>
        {st === 'done' && <button onClick={() => Sa.clearFixture(f.id)} className="wc-btn wc-btn--sm" style={{ padding: '5px 10px', boxShadow: '0 3px 0 var(--shadow)' }}>Undo</button>}
      </div>
      {open && <ScoreStepper f={f} a={f.score ? f.score[0] : 0} b={f.score ? f.score[1] : 0}
        onSave={(a, b) => { Sa.setFixtureResult(f.id, a, b); setOpen(false); }} onCancel={() => setOpen(false)} />}
    </Ca>
  );
}

function PredAdmin(props) {
  const m = props.m;
  function label(opt) {
    if (m.kind === 'player') return opt.name;
    if (m.kind === 'stage') return opt;
    return WCa.TEAMS[opt] ? WCa.TEAMS[opt].name : opt;
  }
  function id(opt) { return m.kind === 'player' ? opt.id : opt; }
  const isTwo = m.kind === 'team2';
  const ans = m.answer;
  function choose(oid) {
    if (isTwo) {
      let arr = Array.isArray(ans) ? ans.slice() : [];
      if (arr.indexOf(oid) >= 0) arr = arr.filter(x => x !== oid); else { arr.push(oid); if (arr.length > 2) arr.shift(); }
      Sa.setPredictionAnswer(m.key, arr.length ? arr : null);
    } else Sa.setPredictionAnswer(m.key, ans === oid ? null : oid);
  }
  const picked = (oid) => isTwo ? (Array.isArray(ans) && ans.indexOf(oid) >= 0) : ans === oid;
  return (
    <Ca flat style={{ padding: '11px 13px', marginBottom: 8 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <div className="dh" style={{ fontSize: 15 }}>{m.q}</div>
        <Cha tone={ans != null && (!isTwo || ans.length) ? 'green' : 'ghost'}>{ans != null && (!isTwo || ans.length) ? 'set' : 'open'}</Cha>
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {m.options.map((opt, i) => {
          const on = picked(id(opt));
          return <button key={i} onClick={() => choose(id(opt))}
            style={{ border: '2px solid ' + (on ? 'var(--ink)' : 'var(--line)'), background: on ? 'var(--yellow)' : '#fff', borderRadius: 10, padding: '6px 10px', fontFamily: 'var(--body)', fontWeight: 800, fontSize: 12.5, cursor: 'pointer' }}>{label(opt)}</button>;
        })}
      </div>
    </Ca>
  );
}

function AdminPanel(props) {
  const [, bump] = aState2(0);
  React.useEffect(() => Sa.subscribe(() => bump(x => x + 1)), []);
  const [sec, setSec] = aState2('results');
  const [mdFilter, setMdFilter] = aState2(0);
  const owned = {};
  Sa.allSync().forEach(p => { owned[p.team] = (owned[p.team] || 0) + 1; });

  const groups = 'ABCDEFGHIJKL'.split('');
  const fixtures = (WCa.FIXTURES || []).filter(f => mdFilter === 0 || f.matchday === mdFilter);
  // group fixtures by date
  const byDate = []; const seen = {};
  fixtures.forEach(f => { if (!seen[f.dateISO]) { seen[f.dateISO] = { label: f.dateLabel, items: [] }; byDate.push(seen[f.dateISO]); } seen[f.dateISO].items.push(f); });

  const secs = [['results', 'Results'], ['teams', 'Teams'], ['predict', 'Predictions']];

  return (
    <div className="moment" style={{ background: 'var(--bg)' }}>
      <div style={{ position: 'sticky', top: 0, zIndex: 5, background: 'var(--ink)', color: '#fff', padding: '16px 18px 12px', display: 'flex', alignItems: 'center', gap: 11 }}>
        <Wa mood="confident" size={44} />
        <div style={{ flex: 1 }}>
          <div className="dh" style={{ fontSize: 20, color: '#fff', lineHeight: 1 }}>Wheesht's clipboard</div>
          <div style={{ fontSize: 11.5, fontWeight: 700, color: 'var(--yellow)' }}>Admin · {Sa.teamsAlive()} teams in · {Sa.allSync().length} entrants</div>
        </div>
        <button onClick={props.onClose} style={{ border: 'none', background: 'rgba(255,255,255,.16)', color: '#fff', width: 34, height: 34, borderRadius: 10, fontSize: 18, fontWeight: 900, cursor: 'pointer' }}>×</button>
      </div>

      <div className="mscroll" style={{ padding: '16px 18px 30px' }}>
        <SHa>Tournament phase</SHa>
        <PhaseSeg />

        <div style={{ display: 'flex', gap: 7, margin: '20px 0 14px' }}>
          {secs.map(([k, lab]) => (
            <button key={k} onClick={() => setSec(k)} className={'wc-chip' + (sec === k ? ' wc-chip--yellow' : '')} style={{ flex: 1, cursor: 'pointer', textAlign: 'center' }}>{lab}</button>
          ))}
        </div>

        {sec === 'results' && <>
          <div style={{ display: 'flex', gap: 6, marginBottom: 12, overflowX: 'auto' }}>
            {[[0, 'All'], [1, 'MD1'], [2, 'MD2'], [3, 'MD3']].map(([k, lab]) => (
              <button key={k} onClick={() => setMdFilter(k)} className={'wc-chip' + (mdFilter === k ? ' wc-chip--yellow' : '')} style={{ cursor: 'pointer', flex: '0 0 auto' }}>{lab}</button>
            ))}
          </div>
          {byDate.map((d, i) => (
            <div key={i}>
              <div style={{ fontFamily: 'var(--disp)', fontWeight: 800, fontSize: 12, color: 'var(--ink2)', margin: '10px 2px 8px', letterSpacing: '.04em' }}>{d.label.toUpperCase()}</div>
              {d.items.map(f => <FixtureAdminRow key={f.id} f={f} owned={owned} />)}
            </div>
          ))}
        </>}

        {sec === 'teams' && <>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--ink2)', marginBottom: 8 }}>Knock a team out and everyone holding it flips to eliminated automatically.</div>
          {groups.map(g => {
            const ts = WCa.TEAM_LIST.filter(t => t.group === g);
            if (!ts.length) return null;
            return <Ca key={g} flat style={{ padding: '8px 14px', marginBottom: 9 }}>
              <div className="dh" style={{ fontSize: 14, marginBottom: 2 }}>Group {g}</div>
              {ts.map(t => <TeamToggle key={t.code} t={t} owners={owned[t.code] || 0} />)}
            </Ca>;
          })}
        </>}

        {sec === 'predict' && <>
          <div style={{ fontSize: 12.5, fontWeight: 600, color: 'var(--ink2)', marginBottom: 10 }}>Set the answer once it's known — every entrant's score and the league re-grade instantly.</div>
          {(WCa.predictions || Sa.PREDICTIONS).map(m => <PredAdmin key={m.key} m={m} />)}
        </>}

        <div style={{ marginTop: 22, borderTop: '2px solid var(--line)', paddingTop: 16 }}>
          <button onClick={() => { if (window.confirm('Reset ALL results, eliminations and answers back to pre-kickoff?')) Sa.adminReset(); }}
            style={{ width: '100%', border: '2px solid var(--red)', borderRadius: 11, background: '#fff', color: 'var(--red)', fontFamily: 'var(--disp)', fontWeight: 800, fontSize: 13, padding: '11px', cursor: 'pointer' }}>Reset tournament to pre-kickoff</button>
        </div>
      </div>
    </div>
  );
}

window.AdminPanel = AdminPanel;
